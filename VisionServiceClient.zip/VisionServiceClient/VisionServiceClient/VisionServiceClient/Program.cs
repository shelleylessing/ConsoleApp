﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HRMobilityClient
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // APIM URL
            string serviceAddress =
                "https://core-apps-dev-api-management.azure-api.net/Credit/Vision1.1";

            HttpClientHandler handler = new HttpClientHandler
            {
                //UseDefaultCredentials = true,
                
                // Service Account Credentials
                Credentials = new NetworkCredential("svc_DevSimo2o", "L4RQewSTzbqb")
            };
           
            var client = new HttpClient(handler);
           
            //visionServiceClient.ClientCredentials.Windows.AllowedImpersonationLevel = TokenImpersonationLevel.Delegation;


            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, serviceAddress);
            request.Headers.TryAddWithoutValidation("Ocp-Apim-Subscription-Key", "3dec01f1e4524c58bb67f876fe8ee2b8"); // Secure the subscription key
            request.Headers.TryAddWithoutValidation("Content-Type", "text/xml");
            request.Headers.TryAddWithoutValidation("SOAPAction", "\"http://fosltd/vision/1.0/IVisionService/GetAllOrgs\"");

            // Read from the json file placed in C:\ directory
            var path = Path.Combine(Directory.GetCurrentDirectory(), "\\vision.xml");
            string jsonString = System.IO.File.ReadAllText(path);

            StringContent content = new StringContent(jsonString, System.Text.Encoding.UTF8, "text/xml");

            request.Content = content;
            var response = client.SendAsync(request);

            if (!response.Result.IsSuccessStatusCode)
            {
                var responseContent = response.Result.Content.ReadAsStringAsync();
            }
        }
    }
}
